﻿
var loadTable = function (container) {
    console.clear();
    container.getElements("tbody tr").each(function (tr) {
        var next = tr.getNext("tr");
        if (next == null || !next.hasClass("details-th")) return;
        var detail = next.getNext("tr");
        if (detail == null || !detail.hasClass("details-td")) return;

        var action = tr.getElement("a");
        var td = tr.getElements("td");
        var orderId = td[0].get("text");
        var money = td[7].get("text").replace(/,/g, "").toFloat();
        var remark = detail.getElements("li").getLast().get("text").replace(/^DMF/, "");
        if (!money) {
            console.log("发生错误，没有检测到金额" + tr.get("html"));
            return;
        }

        //account=qss2262@163.com&orderid=vip9988|20161024200040011100250063742198&tradeno=20161024200040011100250063742198&amount=100.00&fee=0.00&sign=3239b3ec2e40a07099c75efa28456eed
        var data = {
            "account": Config["Alipay"],
            "orderid": remark + "|" + orderId,
            "tradeno": orderId,
            "amount": money.toFixed(2),
            "fee": "0.00"
        };
        data = Utils.Sign(data);
        console.log(data);
        Utils.Save(data, action);
    });
};

var post = function () {
    var yesterday = new Date(new Date().getTime() - 86400000);
    var startDate = yesterday.getFullYear() + "-" + (yesterday.getMonth() + 1) + "-" + yesterday.getDate();
    var endDate = new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate();
    var data = {
        "issubmit": "issubmit",
        "startDate": startDate,
        "endDate": endDate,
        "cusid": "",
        "termid": "",
        "trxid": "",
        "trxcode_comboShowText": "(全部)",
        "trxcode": "",
        "trxstate_comboShowText": "处理成功",
        "trxstate": "31,61",
        "privacctno": "",
        "cusorderid": "",
        "export": "false",
    };
    var container = $$(".site-query-result-export").getLast();
    new Request({
        "url": location.href,
        "onRequest": function () {

        },
        "onComplete": function () {
            post.delay(5 * 1000);
        },
        "onSuccess": function (response) {
            container.empty();
            var regex = /\<table class="site-query-result-table"\>[\s\S\n\r]+?\<\/table\>/;
            var result = regex.exec(response);
            if (!result) return;
            container.set("html", result[0]);
            loadTable(container);
        }
    }).post(data);
};


window.addEvent("domready", function () {
    post();
});